import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


/**
 * Main class for analyzing email data and extracting user statistics.
 */
public class A3 {
    public static Map<String, Node> graph = new HashMap<>();

    /**
     * Node class representing an individual in the email network.
     * Each Node contains an email address, a name, a list of neighbors (people they have sent emails to),
     * and a flag indicating whether the node has been visited.
     */
    static class Node {
        String email = "";
        String name = "";
        List<String> neighbors = new ArrayList<>();
        boolean visited = false;

        /**
         * Constructor for the Node class.
         * @param record Record object containing email information.
         */
        public Node(Record record) {
            email = record.from;
            addEmails(record);
        }

        public String toString() {
            return "\nEmail: " + this.email + " Name: " + this.name + "\nNeighbors: " + this.neighbors;
        }

         /**
         * Adds email addresses to the neighbors list from the given record.
         * @param record Record object containing email information.
         */
        public void addEmails(Record record) {
            for (String toEmail : record.toList) {
                if (this.email.equals(toEmail)) {
                    continue;
                } else if (neighbors.contains(toEmail)) {
                    continue;
                }
                neighbors.add(toEmail);
            }
        }
    }

    /**
     * Record class representing an email record.
     * Each Record contains a sender's email address and a list of recipient email addresses.
     */
    static class Record {
        String from = new String();
        List<String> toList = new ArrayList<>();

        /**
         * Constructor for the Record class.
         * @param from String containing the sender's email address.
         * @param emails List of recipient email addresses.
         */
        public Record(String from, List<String> emails) {
            this.from = from;
            this.toList = emails;
        }

        public String toString() {
            return "From: " + this.from + "\nTo: " + this.toList;
        }
    }

    /**
     * Prompts the user for email addresses and displays user stats.
     */
    public static void getUserStats() {
        Scanner scnr = new Scanner(System.in);
        while (true) {
            // Prompt the user for an email address or to type EXIT to quit
            System.out.println("Email address of the individual (or EXIT to quit): ");
            String email = scnr.nextLine();
    
            // If the user types "EXIT", break the loop and end the program
            if (email.equalsIgnoreCase("EXIT")) {
                break;
            }
    
            // If the email address is not in the graph, inform the user
            if (!graph.containsKey(email)) {
                System.out.println("Email address " + email + " not found in file.");
            } else {
                // Get the number of sent emails for the given email address
                int sentEmails = graph.get(email).neighbors.size();
                System.out.println("* " + email + " has sent messages to " + sentEmails + " others");
    
                // Get the number of received messages for the given email address
                int receivedMessagesCount = countReceivedMessages(email);
                System.out.println("* " + email + " has received messages from " + receivedMessagesCount + " others");
    
                // Get the size of the team that the given email address is a part of
                Set<String> team = getTeam(email);
                System.out.println("* " + email + " is in a team with " + team.size() + " individuals");
            }
        }
        scnr.close();
    }
    

     /**
     * Counts the number of messages received by the given email address.
     * @param email String containing the email address.
     * @return int representing the number of messages received.
     */
    private static int countReceivedMessages(String email) {
        int count = 0; // Initialize a count variable to store the number of received messages
    
        // Iterate through all the nodes in the graph
        for (Node node : graph.values()) {
            // Check if the current node's neighbors list contains the given email
            if (node.neighbors.contains(email)) {
                count++; // Increment the count if the email is found in the neighbors list
            }
        }
    
        return count; // Return the final count of received messages for the given email
    }
    

    /**
     * Retrieves the team of the given email address.
     * @param email String containing the email address.
     * @return Set of Strings representing the team members' email addresses.
     */
    private static Set<String> getTeam(String email) {
        Set<String> team = new HashSet<>();
        Set<String> visited = new HashSet<>();
        dfsTeam(email, team, visited);
        return team;
    }

    /**
     * Performs a depth-first search to find the team of the given email address.
     * @param email String containing the email address.
     * @param visited Set of Strings containing visited email addresses.
     * @param team Set of Strings containing team members' email addresses.
     */
    public static void dfsTeam(String email, Set<String> visited, Set<String> team) {
        if (email == null || visited.contains(email)) {
            return;
        }
    
        visited.add(email);
        Node node = graph.get(email);
    
        // Add a null check for the node
        if (node == null) {
            return;
        }
    
        for (String neighbor : node.neighbors) {
            team.add(neighbor);
            dfsTeam(neighbor, visited, team);
        }
    }

    /**
     * Searches the given directory for email files and processes them.
     * @param file File object representing the directory to be searched.
     */
    public static void search(File file) {
        if (file.isDirectory()) { // If the current file is a directory, read its contents
            File[] files = file.listFiles();
            for (File f : files) {
                search(f); // Recursive call on search to traverse through the directories
            }
        } else {
            String fileName = file.getName();
            if (!file.isDirectory()) { // If the current file is a text file, read its contents
                try {
                	
                    FileReader fileReader = new FileReader(file); // Use a FileReader and a BufferedReader to read the file's contents line by line
                    BufferedReader bufferedReader = new BufferedReader(fileReader);
                    String line;
                    List<String> emails = new ArrayList<>();
                    boolean inEmail = false; // Flag to track if we're currently inside an email
                    String toAddress = null; // Stores the "To" address of the email being read
                    String fromAddress = null; // Stores the "From" address of the email being read
                    String CcAddress = null;
                    String BccAddress = null;
                    
                    while ((line = bufferedReader.readLine()) != null) {
                    	if (line.startsWith("From:")) {
                            // Extract the "From" address from the line using a regular expression
                            Pattern pattern = Pattern.compile("\\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Z]{2,}\\b", Pattern.CASE_INSENSITIVE);
                            Matcher matcher = pattern.matcher(line);
                            if (matcher.find()) {
                                fromAddress = matcher.group(); // Store the "From" address
                            }
                        } else if (line.startsWith("To:")) {
                            // Extract the "To" address from the line using a regular expression
                            Pattern pattern = Pattern.compile("\\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Z]{2,}\\b", Pattern.CASE_INSENSITIVE);
                            Matcher matcher = pattern.matcher(line);
                            while (matcher.find()) {
                                emails.add(matcher.group()); // Store the "To" address
                            }
                        } else if (line.startsWith("Cc:")) {
                        	Pattern pattern = Pattern.compile("\\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Z]{2,}\\b", Pattern.CASE_INSENSITIVE);
                            Matcher matcher = pattern.matcher(line);
                            while (matcher.find()) {
                                emails.add(matcher.group()); // Store the "Cc" address
                            }
              
                        } else if (line.startsWith("Bcc:")) {
                        	Pattern pattern = Pattern.compile("\\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Z]{2,}\\b", Pattern.CASE_INSENSITIVE);
                            Matcher matcher = pattern.matcher(line);
                            while (matcher.find()) {
                                emails.add(matcher.group()); // Store the "Bcc" address
                            }
                        }
                    }
                    
                    bufferedReader.close();
                    Record record = new Record(fromAddress, emails);
                    if (graph.containsKey(fromAddress)) {
                    	graph.get(fromAddress).addEmails(record);
                    	
                    } else {
                    	graph.put(fromAddress, new Node (record));
                    }
                    
                    //System.out.println(record + "\n");
                    // Reset the "To" and "From" addresses for the next email
                    toAddress = null;
                    fromAddress = null;
                    
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    /**
     * Prints the graph representation of the email network.
     */
    public static void printGraph () {
		for (Node node : graph.values()) {
			System.out.println(node);
		}
		
	}

    public static void main(String[] args) {
        String directoryPath = "maildir";
        File directory = new File(directoryPath); // create a File object
        search(directory);

        printGraph();
        getUserStats();
    }
}
