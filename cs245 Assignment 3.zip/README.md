
# CS245 - Assignment 03

## Data structures

In the given code, various data structures are used to store and manipulate the data:

### HashMap<String, Node> 
This is the main data structure, graph, that stores the email address as the key (a String) and a Node object as the value. The Node object represents a single individual in the graph, containing information about their email, name, and list of neighbors (email addresses of people they've sent emails to). HashMap is used here to provide constant time (O(1)) access to the Node objects associated with a given email address.

### ArrayList<String>
The Node class has a field List<String> neighbors, which is an ArrayList of Strings. This list stores the email addresses of neighbors for each Node (i.e., the people the individual has sent emails to). ArrayList is used here because the number of neighbors is not fixed, and ArrayList provides efficient insertion and access to its elements.

### HashSet<String> 
This data structure is used in the getTeam() method to store the email addresses of team members and visited email addresses. It helps to perform depth-first search (DFS) on the graph. HashSet allows constant time (O(1)) insertion and lookup, and ensures that each email address is stored only once (eliminating duplicates).

## Time Complexity
The time complexity of the code depends on the number of emails processed and the depth of the graph traversal during the DFS. In the worst case, it could be O(n^2), where 'n' is the number of unique email addresses in the graph. This worst-case complexity arises from the fact that each Node may have to be visited multiple times during the DFS, and the countReceivedMessages() method iterates through all nodes in the graph to count the received messages.


## Code Working

1. The search() method recursively traverses the file system, starting from the given maildir directory, and processes all text files encountered.

2. For each text file, the code reads the email's "From", "To", "Cc", and "Bcc" fields and creates a Record object containing the "From" email address and a list of email addresses in the "To", "Cc", and "Bcc" fields.

3. For each Record object, if the graph already contains a Node for the "From" email address, the existing Node is updated to add the new neighbors. Otherwise, a new Node object is created and added to the graph.

4. After the graph is constructed, the getUserStats() method is used to get the user statistics (number of sent messages, number of received messages, and team size) for a given email address.

5. The countReceivedMessages() method iterates through the graph, counting the number of unique email addresses that have the given email address as a neighbor (i.e., the number of received messages).

6. The getTeam() method performs a DFS on the graph, starting from the given email address, to find all the email addresses that are part of the same "team" (i.e., connected through sent emails). The dfsTeam() helper method is used for the DFS traversal.